## TBLASTN 分析报告

### BLAST 参数信息

| 参数 | 值 |
|------|-----|
| **程序** | TBLASTN |
| **版本** | TBLASTN 2.17.0+ |
| **数据库** | nt |
| **查询序列** | CAP49952_1 |
| **序列长度** | 293 bp |
| **E值阈值** | 0.05 |
| **替换矩阵** | BLOSUM62 |
| **空位罚分** | 开启: 11, 延伸: 2 |
| **低复杂度过滤** | 开启 |

### 高得分比对

| 排名 | 登录号 | 描述 | 物种 | 得分 | E值 | 一致性 | 相似度 |
|------|--------|------|------|------|-----|--------|--------|
| 1 | CP012145 | Xanthomonas campestris pv. campestris strain ICMP 21080, complete genome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 421.8 | 2e-126 | 76.7% | 80.3% |
| 2 | CP066984 | Xanthomonas campestris pv. campestris strain 27-10 chromosome, complete genome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 421.8 | 2e-126 | 76.7% | 80.3% |
| 3 | CP066985 | Xanthomonas campestris pv. campestris strain 25-4 chromosome, complete genome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 421.8 | 2e-126 | 76.7% | 80.3% |
| 4 | CP066982 | Xanthomonas campestris pv. campestris strain 27-9 chromosome, complete genome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 421.8 | 2e-126 | 76.7% | 80.3% |
| 5 | CP066986 | Xanthomonas campestris pv. campestris strain 15-1 chromosome, complete genome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 421.8 | 2e-126 | 76.7% | 80.3% |

### 阅读框分析

- 主要阅读框: -2
- 链方向: 反向

### 质量评估

- 覆盖度质量: 优秀（>=90%）
- 显著性: 高度显著（E < 1e-50）
- 相似度评估: 高度相似（>=80%）
- 综合评价: 高质量比对