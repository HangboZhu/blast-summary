## blastn 分析报告

### BLAST 参数信息

| 参数 | 值 |
|------|-----|
| **程序** | BLASTN |
| **版本** | BLASTN 2.17.0+ |
| **数据库** | PangoRef |
| **查询序列** | C_AA019067_1_Severe_acute_respiratory_syndrome_coronavirus_2_isolate_SARS_CoV_2_human_CHN_SKLID_ZJU_S33_hCoV_19_2022_ORF1ab_polyprotein__ORF1ab___ORF1a_polyprotein__ORF1ab___surface_glycoprotein__S___ORF3a_protein__ORF3a___envelope_protein__E___membrane_glycoprotein__M___ORF6_protein__ORF6___ORF7a_protein__ORF7a___ORF7b__ORF7b___ORF8_protein__ORF8___nucleocapsid_phosphoprotein__N___and_ORF10_protein__ORF10__genes__complete_cds |
| **序列长度** | 29814 bp |
| **E值阈值** | 0.05 |
| **空位罚分** | 开启: 0, 延伸: 0 |
| **低复杂度过滤** | 开启 |

### 高得分比对

| 排名 | 登录号 | 描述 | 得分 | E值 | 一致性 |
|------|--------|------|------|-----|--------|
| 1 | EPI_ISL_14803419 | hCoV-19/USA/CA-HLX-STM-SR4T6P8M7/2022\|BF.8 | 16440.0 | 0.0 | 77.2% |
| 2 | EPI_ISL_16623662 | hCoV-19/Latvia/22513219/2022\|BF.7 | 16427.1 | 0.0 | 77.2% |
| 3 | EPI_ISL_16867341 | hCoV-19/Switzerland/BS-UHB-USB_0a0135a2/2023\|BF.7 | 16421.5 | 0.0 | 77.2% |
| 4 | EPI_ISL_14377278 | hCoV-19/USA/CA-HLX-STM-ZTZZ9NR5N/2022\|BA.5.6.2 | 16414.1 | 0.0 | 77.2% |
| 5 | EPI_ISL_14220871 | hCoV-19/USA/CA-HLX-STM-TE8TU3NDP/2022\|BA.5.1.25 | 16414.1 | 0.0 | 77.2% |

### 质量评估

- 覆盖度质量: 优秀（>=90%）
- 显著性: 高度显著（E < 1e-50）
- 综合评价: 高质量比对