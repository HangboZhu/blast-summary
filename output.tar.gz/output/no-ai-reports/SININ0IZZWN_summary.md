## BLASTP 分析报告

### BLAST 参数信息

| 参数 | 值 |
|------|-----|
| **程序** | BLASTP |
| **版本** | BLASTP 2.17.0+ |
| **数据库** | swissprot |
| **查询序列** | HBA_HUMAN |
| **序列长度** | 142 bp |
| **E值阈值** | 0.05 |
| **替换矩阵** | BLOSUM62 |
| **空位罚分** | 开启: 11, 延伸: 2 |
| **低复杂度过滤** | 关闭 |

### 高得分比对

| 排名 | 登录号 | 描述 | 物种 | 得分 | E值 | 一致性 | 相似度 |
|------|--------|------|------|------|-----|--------|--------|
| 1 | P69905 | RecName: Full=Hemoglobin subunit alpha; AltName: Full=Alpha-globin; AltName: Full=Hemoglobin alpha chain; Contains: RecName: Full=Hemopressin [Homo sapiens] >sp\|P69906.2\| RecName: Full=Hemoglobin subunit alpha; AltName: Full=Alpha-globin; AltName: Full=Hemoglobin alpha chain; Contains: RecName: Full=Hemopressin [Pan paniscus] >sp\|P69907.2\| RecName: Full=Hemoglobin subunit alpha; AltName: Full=Alpha-globin; AltName: Full=Hemoglobin alpha chain; Contains: RecName: Full=Hemopressin [Pan troglodytes] | Homo sapiens (human) [primates] | 317.7 | 3e-109 | 100.0% | 100.0% |
| 2 | P01923 | RecName: Full=Hemoglobin subunit alpha; AltName: Full=Alpha-globin; AltName: Full=Hemoglobin alpha chain; Contains: RecName: Full=Hemopressin [Gorilla gorilla gorilla] | Gorilla gorilla gorilla (western lowland gorilla) [primates] | 312.5 | 2e-107 | 99.3% | 100.0% |
| 3 | Q9TS35 | RecName: Full=Hemoglobin subunit alpha-1; AltName: Full=Alpha-1-globin; AltName: Full=Hemoglobin alpha-1 chain; Contains: RecName: Full=Hemopressin [Hylobates lar] | Hylobates lar (common gibbon) [primates] | 311.7 | 5e-107 | 98.6% | 99.3% |
| 4 | P06635 | RecName: Full=Hemoglobin subunit alpha; AltName: Full=Alpha-globin; AltName: Full=Hemoglobin alpha chain; Contains: RecName: Full=Hemopressin [Pongo pygmaeus] | Pongo pygmaeus (Bornean orangutan) [primates] | 311.3 | 8e-107 | 97.9% | 98.6% |
| 5 | P01924 | RecName: Full=Hemoglobin subunit alpha; AltName: Full=Alpha-globin; AltName: Full=Hemoglobin alpha chain; Contains: RecName: Full=Hemopressin [Semnopithecus entellus] | Semnopithecus entellus (Hanuman langur) [primates] | 308.7 | 9e-106 | 97.9% | 98.6% |

### 功能预测

- 预测功能: subunit; chain; hemoglobin
- 蛋白质家族: Hemoglobin subunit alpha
- 置信度: high

### 质量评估

- 覆盖度质量: 优秀（>=90%）
- 显著性: 高度显著（E < 1e-50）
- 相似度评估: 高度相似（>=80%）
- 综合评价: 高质量比对