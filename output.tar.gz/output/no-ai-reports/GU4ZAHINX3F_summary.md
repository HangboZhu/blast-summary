## TBLASTX 分析报告

### BLAST 参数信息

| 参数 | 值 |
|------|-----|
| **程序** | TBLASTX |
| **版本** | TBLASTX 2.17.0+ |
| **数据库** | nt |
| **查询序列** | NM_000558_5__HBA1 |
| **序列长度** | 577 bp |
| **E值阈值** | 0.05 |
| **替换矩阵** | BLOSUM62 |
| **空位罚分** | 开启: 11, 延伸: 1 |
| **低复杂度过滤** | 开启 |

### 高得分比对

| 排名 | 登录号 | 描述 | 物种 | 得分 | E值 | 一致性 |
|------|--------|------|------|------|-----|--------|
| 1 | KX533500 | Homo sapiens Hemoglobin subunit alpha (HBA2) mRNA, complete cds | Homo sapiens (human) [primates] | 54.7 | 5.65e-14 | 46.3% |
| 2 | XM_003809393 | PREDICTED: Pan paniscus hemoglobin subunit alpha (LOC100984160), mRNA | - | 54.2 | 1.48e-34 | 71.0% |
| 3 | NM_001042626 | Pan troglodytes hemoglobin subunit alpha 1 (HBA1), mRNA >gi\|38222\|emb\|X00226.1\| Pan troglodytes alpha-globin messenger RNA | - | 54.2 | 2.28e-34 | 71.0% |
| 4 | V00493 | Homo sapiens messenger mRNA for hemoglobin alpha chain | Homo sapiens (human) [primates] | 54.2 | 1.85e-31 | 71.0% |
| 5 | XM_055078620 | PREDICTED: Pan troglodytes hemoglobin subunit alpha (LOC129388389), mRNA | - | 54.2 | 1.77e-31 | 71.0% |

### 功能预测

- 预测功能: subunit; hemoglobin; globin
- 置信度: low

### 质量评估

- 覆盖度质量: 优秀（>=90%）
- 显著性: 显著（E < 1e-10）
- 相似度评估: 中等相似（60-80%）
- 综合评价: 高质量比对