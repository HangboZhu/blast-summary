## BLASTX 分析报告

### BLAST 参数信息

| 参数 | 值 |
|------|-----|
| **程序** | BLASTX |
| **版本** | BLASTX 2.17.0+ |
| **数据库** | swissprot |
| **查询序列** | ncov_seq |
| **序列长度** | 839 bp |
| **E值阈值** | 0.05 |
| **替换矩阵** | BLOSUM62 |
| **空位罚分** | 开启: 11, 延伸: 2 |
| **低复杂度过滤** | 开启 |

### 高得分比对

| 排名 | 登录号 | 描述 | 物种 | 得分 | E值 | 一致性 | 相似度 |
|------|--------|------|------|------|-----|--------|--------|
| 1 | P0DTC1 | RecName: Full=Replicase polyprotein 1a; Short=pp1a; AltName: Full=ORF1a polyprotein; Contains: RecName: Full=Host translation inhibitor nsp1; AltName: Full=Leader protein; AltName: Full=Non-structural protein 1; Short=nsp1; Contains: RecName: Full=Non-structural protein 2; Short=nsp2; AltName: Full=p65 homolog; Contains: RecName: Full=Papain-like protease nsp3; AltName: Full=Non-structural protein 3; Short=nsp3; AltName: Full=PL2-PRO; AltName: Full=Papain-like proteinase; Short=PL-PRO; Contains: RecName: Full=Non-structural protein 4; Short=nsp4; Contains: RecName: Full=3C-like proteinase nsp5; Short=3CL-PRO; Short=3CLp; AltName: Full=Main protease; Short=Mpro; AltName: Full=Non-structural protein 5; Short=nsp5; AltName: Full=SARS coronavirus main proteinase; Contains: RecName: Full=Non-structural protein 6; Short=nsp6; Contains: RecName: Full=Non-structural protein 7; Short=nsp7; Contains: RecName: Full=Non-structural protein 8; Short=nsp8; Contains: RecName: Full=RNA-capping enzyme subunit nsp9; AltName: Full=Non-structural protein 9; Short=nsp9; Contains: RecName: Full=Non-structural protein 10; Short=nsp10; AltName: Full=Growth factor-like peptide; Short=GFL; Contains: RecName: Full=Non-structural protein 11; Short=nsp11 [Severe acute respiratory syndrome coronavirus 2] | Severe acute respiratory syndrome coronavirus 2  [viruses] | 43.9 | 2.14e-03 | 37.7% | 50.7% |
| 2 | P0DTD1 | RecName: Full=Replicase polyprotein 1ab; Short=pp1ab; AltName: Full=ORF1ab polyprotein; Contains: RecName: Full=Host translation inhibitor nsp1; AltName: Full=Leader protein; AltName: Full=Non-structural protein 1; Short=nsp1; Contains: RecName: Full=Non-structural protein 2; Short=nsp2; AltName: Full=p65 homolog; Contains: RecName: Full=Papain-like protease nsp3; AltName: Full=Non-structural protein 3; Short=nsp3; AltName: Full=PL2-PRO; AltName: Full=Papain-like proteinase; Short=PL-PRO; Contains: RecName: Full=Non-structural protein 4; Short=nsp4; Contains: RecName: Full=3C-like proteinase nsp5; Short=3CL-PRO; Short=3CLp; AltName: Full=Main protease; Short=Mpro; AltName: Full=Non-structural protein 5; Short=nsp5; AltName: Full=SARS coronavirus main proteinase; Contains: RecName: Full=Non-structural protein 6; Short=nsp6; Contains: RecName: Full=Non-structural protein 7; Short=nsp7; Contains: RecName: Full=Non-structural protein 8; Short=nsp8; Contains: RecName: Full=Viral protein genome-linked nsp9; AltName: Full=Non-structural protein 9; Short=nsp9; AltName: Full=RNA-capping enzyme subunit nsp9; Contains: RecName: Full=Non-structural protein 10; Short=nsp10; AltName: Full=Growth factor-like peptide; Short=GFL; Contains: RecName: Full=RNA-directed RNA polymerase nsp12; Short=Pol; Short=RdRp; AltName: Full=Non-structural protein 12; Short=nsp12; Contains: RecName: Full=Helicase nsp13; Short=Hel; AltName: Full=Non-structural protein 13; Short=nsp13; Contains: RecName: Full=Guanine-N7 methyltransferase nsp14; AltName: Full=Non-structural protein 14; Short=nsp14; AltName: Full=Proofreading exoribonuclease nsp14; Short=ExoN; Contains: RecName: Full=Uridylate-specific endoribonuclease nsp15; AltName: Full=NendoU; AltName: Full=Non-structural protein 15; Short=nsp15; Contains: RecName: Full=2'-O-methyltransferase nsp16; AltName: Full=Non-structural protein 16; Short=nsp16 [Severe acute respiratory syndrome coronavirus 2] | Severe acute respiratory syndrome coronavirus 2  [viruses] | 43.9 | 2.15e-03 | 37.7% | 50.7% |

### 阅读框分析

- 主要阅读框: 3
- 链方向: 正向

### 功能预测

- 预测功能: protease; factor; enzyme
- 蛋白质家族: Replicase polyprotein 1a
- 置信度: low

### 质量评估

- 覆盖度质量: 较差（<50%）
- 显著性: 边缘显著（E < 0.05）
- 相似度评估: 低相似度（40-60%）
- 综合评价: 低质量比对