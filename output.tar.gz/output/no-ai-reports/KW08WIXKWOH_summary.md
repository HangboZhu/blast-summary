## TBLASTN 分析报告

### BLAST 参数信息

| 参数 | 值 |
|------|-----|
| **程序** | TBLASTN |
| **版本** | TBLASTN 2.17.0+ |
| **数据库** | nt_prok |
| **查询序列** | CAP49952_1 |
| **序列长度** | 293 bp |
| **E值阈值** | 0.05 |
| **替换矩阵** | BLOSUM62 |
| **空位罚分** | 开启: 11, 延伸: 2 |
| **低复杂度过滤** | 开启 |

### 高得分比对

| 排名 | 登录号 | 描述 | 物种 | 得分 | E值 | 一致性 | 相似度 |
|------|--------|------|------|------|-----|--------|--------|
| 1 | AP019682 | Xanthomonas campestris pv. campestris MAFF106712 DNA, complete genome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 631.3 | 0.0 | 100.0% | 100.0% |
| 2 | CP029484 | Xanthomonas campestris pv. campestris strain Xcc8004_Xcc2 chromosome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 631.3 | 0.0 | 100.0% | 100.0% |
| 3 | CP029483 | Xanthomonas campestris pv. campestris strain Xcc8004_Xcc1 chromosome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 631.3 | 0.0 | 100.0% | 100.0% |
| 4 | CP156011 | Xanthomonas campestris pv. campestris strain CFBP 6943 chromosome, complete genome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 631.3 | 0.0 | 100.0% | 100.0% |
| 5 | CP156010 | Xanthomonas campestris pv. campestris strain IPO 634 chromosome, complete genome | Xanthomonas campestris pv. campestris  [g-proteobacteria] | 631.3 | 0.0 | 100.0% | 100.0% |

### 阅读框分析

- 主要阅读框: 2
- 链方向: 正向

### 质量评估

- 覆盖度质量: 优秀（>=90%）
- 显著性: 高度显著（E < 1e-50）
- 相似度评估: 中等相似（60-80%）
- 综合评价: 高质量比对