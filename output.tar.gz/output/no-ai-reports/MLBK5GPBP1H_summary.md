## TBLASTX 分析报告

### BLAST 参数信息

| 参数 | 值 |
|------|-----|
| **程序** | TBLASTX |
| **版本** | TBLASTX 2.17.0+ |
| **数据库** | nt |
| **查询序列** | NM_000558_5__HBA1 |
| **序列长度** | 577 bp |
| **E值阈值** | 0.05 |
| **替换矩阵** | BLOSUM62 |
| **空位罚分** | 开启: 11, 延伸: 1 |
| **低复杂度过滤** | 开启 |

### 高得分比对

| 排名 | 登录号 | 描述 | 物种 | 得分 | E值 | 一致性 |
|------|--------|------|------|------|-----|--------|
| 1 | NM_000558 | Homo sapiens hemoglobin subunit alpha 1 (HBA1), mRNA | - | 460.2 | 8e-125 | 100.0% |
| 2 | BC005931 | Homo sapiens hemoglobin, alpha 1, mRNA (cDNA clone MGC:14541 IMAGE:4047053), complete cds | Homo sapiens (human) [primates] | 460.2 | 8e-125 | 100.0% |
| 3 | AK223392 | Homo sapiens mRNA for alpha 2 globin variant, clone: FCC107C11 | Homo sapiens (human) [primates] | 457.9 | 4e-124 | 99.5% |
| 4 | BC032122 | Homo sapiens hemoglobin, alpha 1, mRNA (cDNA clone MGC:29691 IMAGE:4849981), complete cds | Homo sapiens (human) [primates] | 445.5 | 2e-120 | 100.0% |
| 5 | BC050661 | Homo sapiens hemoglobin, alpha 1, mRNA (cDNA clone MGC:60177 IMAGE:5209215), complete cds | Homo sapiens (human) [primates] | 445.5 | 2e-120 | 100.0% |

### 功能预测

- 预测功能: subunit; hemoglobin; globin
- 置信度: high

### 质量评估

- 覆盖度质量: 优秀（>=90%）
- 显著性: 高度显著（E < 1e-50）
- 相似度评估: 高度相似（>=80%）
- 综合评价: 高质量比对