## blastn 分析报告

### BLAST 参数信息

| 参数 | 值 |
|------|-----|
| **程序** | BLASTN |
| **版本** | BLASTN 2.17.0+ |
| **数据库** | PangoRef |
| **查询序列** | C_AA019067_1_Severe_acute_respiratory_syndrome_coronavirus_2_isolate_SARS_CoV_2_human_CHN_SKLID_ZJU_S33_hCoV_19_2022_ORF1ab_polyprotein__ORF1ab___ORF1a_polyprotein__ORF1ab___surface_glycoprotein__S___ORF3a_protein__ORF3a___envelope_protein__E___membrane_glycoprotein__M___ORF6_protein__ORF6___ORF7a_protein__ORF7a___ORF7b__ORF7b___ORF8_protein__ORF8___nucleocapsid_phosphoprotein__N___and_ORF10_protein__ORF10__genes__complete_cds |
| **序列长度** | 29832 bp |
| **E值阈值** | 0.05 |
| **空位罚分** | 开启: 0, 延伸: 0 |
| **低复杂度过滤** | 开启 |

### 高得分比对

| 排名 | 登录号 | 描述 | 得分 | E值 | 一致性 |
|------|--------|------|------|-----|--------|
| 1 | EPI_ISL_17488540 | hCoV-19/Fujian/FCDC-QZ02S036/2023\|BF.7.14.2 | 55001.7 | 0.0 | 100.0% |
| 2 | EPI_ISL_17489579 | hCoV-19/Fujian/FCDC-FJ01S059/2023\|BF.7.14.3 | 54987.0 | 0.0 | 100.0% |
| 3 | EPI_ISL_14221201 | hCoV-19/USA/CA-HLX-STM-WVWWQJC9T/2022\|BA.5 | 54987.0 | 0.0 | 99.9% |
| 4 | EPI_ISL_14495217 | hCoV-19/Japan/RIMD12396/2022\|BV.2 | 54974.0 | 0.0 | 99.9% |
| 5 | EPI_ISL_14220871 | hCoV-19/USA/CA-HLX-STM-TE8TU3NDP/2022\|BA.5.1.25 | 54968.5 | 0.0 | 99.9% |

### 质量评估

- 覆盖度质量: 优秀（>=90%）
- 显著性: 高度显著（E < 1e-50）
- 综合评价: 高质量比对