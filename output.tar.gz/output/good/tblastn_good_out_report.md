## TBLASTN 分析报告

### 高得分比对

| 排名 | 登录号 | 描述 | 得分 | E值 | 一致性 | 相似度 |
|------|--------|------|------|-----|--------|--------|
| 1 | NC_000002 | Homo sapiens chromosome 2, GRCh38.p13 Primary Assembly | 745.3 | 0.0 | 99.7% | 99.7% |
| 2 | NC_000017 | Homo sapiens chromosome 17, GRCh38.p13 Primary Assembly | 554.6 | 7e-156 | 76.6% | 88.3% |
| 3 | NC_000012 | Homo sapiens chromosome 12, GRCh38.p13 Primary Assembly | 542.6 | 3e-152 | 85.9% | 93.9% |
| 4 | NC_000003 | Homo sapiens chromosome 3, GRCh38.p13 Primary Assembly | 539.2 | 4e-151 | 74.4% | 87.8% |
| 5 | NC_000001 | Homo sapiens chromosome 1, GRCh38.p13 Primary Assembly | 61.9 | 4.98e-07 | 32.1% | 52.8% |

### 阅读框分析

- 主要阅读框: -3
- 链方向: 反向

### 质量评估

- 覆盖度质量: 优秀（>=90%）
- 显著性: 高度显著（E < 1e-50）
- 相似度评估: 高度相似（>=80%）
- 综合评价: 高质量比对

---

## 生物学解释



**AI analysis temporarily unavailable**: AI API request timed out